const express=require("express")
const app=express()
const mysql=require("mysql2")
const bodyParse=require("body-parser")

app.set("view engine","ejs")
app.use(bodyParse.urlencoded({extended:true}))

//database connection
const connection=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"nelsonthegreat123",
    database:"dairyapp"
})
connection.connect((err)=>{
    if(err){
console.log(err)
    }
    else{
        console.log("connected")
    }
})
///rendering signup page
app.get("/",(req,res)=>{
    res.render("signup")
})
///inserting the data which we get from the signup page
app.post("/insert",(req,res)=>{
var sql = "INSERT INTO signup (name, email, phone, password) VALUES (?, ?, ?, ?)";

var data=[req.body.name,req.body.email,req.body.contact,req.body.password]
connection.query(sql,data,(err)=>{
    if(err){
        console.log(err)
        return
    }
    else{
        console.log("signup from data is added sucessfully")
    }
    res.redirect("Login")
})
//after signup we are rendering Login page
})
app.get("/Login",(req,res)=>{
    res.render("Login")
})
//checking if the data intered in login page is valid or not
app.post("/check-data",(req,res)=>{
    const sql = "SELECT * FROM signup WHERE name = ? AND password = ?";
    const data1=[req.body.username,req.body.password]
    console.log(data1)
    connection.query(sql,data1,(err,result)=>{
        if (err) throw err
        if(result.length>0){
            res.redirect(`/home?data=${encodeURIComponent(data1[1])}`);
            return
        }
        else{
            console.log("Invalid username or password.");
            res.render("page-not-found")
        }
    })
})

//displaying the data entery from
app.get("/add-entry",(req,res)=>{
    res.render("addEntryFrom.ejs")
})
//sign-out from the website
app.get("/signout",(req,res)=>{
    res.render("Login")
})
//add data in diery entery table
app.post("/add-entry-logic", (req, res) => {
    // Make sure the table schema matches the query
    const sql2 = `INSERT INTO diary_entries (title, content, entry_date, entry_time, password) VALUES (?, ?, ?, ?, ?)`;
    const data2 = [req.body.title, req.body.content, req.body.entry_date, req.body.entry_time, req.body.password];

    connection.query(sql2, data2, (err) => {
        if (err) {
            console.log(err);
            return;
        } else {
            res.redirect(`/home?data=${encodeURIComponent(req.body.password)}`);
        }
    });
});

//rendeing home page
app.get("/home", (req, res) => {
    const data3 = req.query.data;
    const sql = 'SELECT * FROM diary_entries WHERE password = ? ORDER BY entry_date DESC, entry_time DESC';

    connection.query(sql, [data3], (err, results) => {
        if (err) {
            console.error('Error fetching data:', err.stack);
            return res.status(500).send('Server error');
        }

        if (results.length === 0) {
            console.log("No entries found for the provided password.");
            return res.render("home", { data: [] });  // Render an empty array if no entries
        }

        res.render("home", { data: results });
    });

    console.log("Password received: ", data3);
});


//deleting the entrys
app.post('/delete-entry', (req, res) => {
    const entryId = req.body.entry_id;  // Get the entry ID from the request body
    const password = req.body.password; // Get the password from the hidden input

    // Log the entry ID and password to verify
    console.log(`Deleting entry with ID: ${entryId}, Password: ${password}`);

    if (!entryId) {
        return res.status(400).send('Entry ID is required');
    }

    const sql = 'DELETE FROM diary_entries WHERE id = ?';

    connection.query(sql, [entryId], (err, result) => {
        if (err) {
            console.error('Error deleting entry:', err.stack);
            return res.status(500).send('Server error');
        }

        if (result.affectedRows > 0) {
            console.log(`Successfully deleted entry with ID: ${entryId}`);
        } else {
            console.log(`No entry found with ID: ${entryId}`);
        }

        // Redirect back to the home page, including the password in the query parameter
        res.redirect(`/home?data=${encodeURIComponent(password)}`);
    });
});


app.listen(3000)